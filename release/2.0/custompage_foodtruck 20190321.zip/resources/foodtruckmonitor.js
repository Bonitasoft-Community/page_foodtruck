'use strict';
/**
 *
 */

(function() {


var appCommand = angular.module('foodtruckmonitor', ['googlechart', 'ui.bootstrap', 'ngModal', 'ngSanitize']);






// --------------------------------------------------------------------------
//
// Controler Ping
//
// --------------------------------------------------------------------------

// Ping the server
appCommand.controller('FoodTruckControler',
	function ( $http, $scope,$sce ) {

	
	this.showgithublogin=false;
	
	// --------------------------------------------------------------------------
	//
	//  General
	//
	// --------------------------------------------------------------------------

	this.isshowhistory = false;
	this.isshowsetting = false;
	this.isshowhelp=false;
	this.navbaractiv = 'all';
	
	this.getNavClass = function( tabtodisplay )
	{
		if (this.navbaractiv === tabtodisplay)
		 return 'ng-isolate-scope active';
		return 'ng-isolate-scope';
	}
	
	this.getListEvents = function ( listevents ) {
		return $sce.trustAsHtml(  listevents);
	}
	
	
	                       
	
	// --------------------------------------------------------------------------
	//
	//  Custom page
	//
	// --------------------------------------------------------------------------
	this.loading= false;
	this.custompage={};
	this.param={};
	this.param.showlocal=true;
	this.param.showBonitaAppsStore=true;
	this.param.github ={};
	this.param.gold=true;
	
	// in Community version, the addProfile is not allowed
	this.generalAllowAddProfile=false;
	

	
	// filter is ALL, NEW, MYPLATFORM, UPDATE 
	// type is custom-page, restapi, widget, all
	this.pilotartefact = { 'filterstatus' : 'ALL', 'type': 'custom-page'};
	
	
	
	// Reload the artefacts
	// init is done via the loadParameters
	this.reloadartefacts = function( reload )
	{
		this.loading = true;
		/** ask ALL item, we filter on the AngularJs after */
		this.param.filterstatus='ALL';
		this.param.type='ALL';

		// reload ? Ask the BonitaStore
		this.param.reload=reload;
		
		var json = encodeURI(angular.toJson(this.param, false));
		var self=this;
		// alert("json="+json);
		
		this.custompage.status="Collect in progress";

		$http.get( '?page=custompage_foodtruck&action=listartefacts&json='+json )
				.then( function ( jsonResult ) {
						console.log("result",jsonResult.data);
						self.custompage.list 			= jsonResult.data.list;
						self.custompage.listevents 		= jsonResult.data.listevents;
						self.alllistprofiles 			= jsonResult.data.alllistprofiles;
						self.generalAllowAddProfile 	= jsonResult.data.isAllowAddProfile;
						self.custompage.status="";
				},
				function(jsonResult ) {
					// alert("Can't connect the server ("+jsonResult.status+")");
					self.statusresource="Can't connect the server ("+jsonResult.status+")";
				})
				.finally(function() {
					self.loading = false;
				});

	}
	// don't reload now, in fact loadParameters will reload artefact
	

	/** set a specific status */
	var listStatus = { ALL : "ALL", MYPLATFORM : "MYPLATFORM", WHATSUPDATE : "WHATSUPDATE", WHATSNEWS : "WHATSNEWS" }; 
	var listType = { "CUSTOMPAGE" : "Custom Page" };
	
	
	this.setStatusArtefact = function( filterstatus )
	{
		this.pilotartefact.filterstatus= filterstatus;
	}
	 
	/** set a specific type of artefact */
	this.setTypeArtefact = function( type )
	{
		this.pilotartefact.type= type;
	}

	
	/**
	 * build the list of artefact according the filterstatus, and the type
	 */
	this.getListArtefacts = function () {
		
		var listArtefacts = [];
		for (var i in this.custompage.list)
		{
			var artefact = this.custompage.list[ i ];
			
			// first, type : to do
			
			// second, status
			if (this.pilotartefact.filterstatus == listStatus.ALL )
				listArtefacts.push( artefact );
			else if  (this.pilotartefact.filterstatus == listStatus.MYPLATFORM)
			{
				if (artefact.status == 'LOCAL' || artefact.status == 'OK' || artefact.status == 'TOUPDATE')
					listArtefacts.push( artefact );
			}
			else if  (this.pilotartefact.filterstatus == listStatus.WHATSUPDATE)
			{
				if (artefact.status == 'TOUPDATE')
					listArtefacts.push( artefact );
			}
			else if  (this.pilotartefact.filterstatus == listStatus.WHATSNEWS )
			{
				if (artefact.status == 'NEW')
					listArtefacts.push( artefact );
			}
		}
		return listArtefacts;
	}
	
	// dowload 
	this.downloadcustompage = function( custompageinfo )
	{
		custompageinfo.oldstatus=custompageinfo.status;
		custompageinfo.status="INDOWNLOAD";
		var self=this;
		
		this.custompage.status="Download "+custompageinfo.displayname;

		// note : the server can't save any information (thanks custom page in Debug mode !) so we have to send back all information.
		var param = { "appsname":custompageinfo.appsname,
					"appsid": custompageinfo.appsid,
					"status": custompageinfo.status,
					'urldownload':custompageinfo.urldownload,
					"storegithubname":custompageinfo.storegithubname,
					"github" : this.param.github};
		var json = encodeURI( angular.toJson(param, true));
		
		
		
		this.statusfoodtruck = "Download "+custompageinfo.installid+" in progress";
		$http.get( '?page=custompage_foodtruck&action=downloadcustompage&json='+json)
				.then( function ( jsonResult ) {
					// self.custompage.list 		= jsonResult.data.list;
					custompageinfo.status=  jsonResult.data.statuscustompage;
					custompageinfo.isAllowAddProfile=  jsonResult.data.isAllowAddProfile;
					
					self.custompage.listevents 		= jsonResult.data.listevents;
					self.custompage.status="";
					
					// alert("Result download ="+  angular.toJson(jsonResult, true) );

				},
				function(jsonResult) {
					alert("downloadcustompage: Can't connect the server ("+jsonResult.status+")");
					self.statusresource="Can't connect the server ("+jsonResult.status+")";
					custompageinfo.status=custompageinfo.oldstatus;
					});

	}

	
	this.getlistprofiletoadd = function(custompageinfo ) {
		var listprofiletoadd=[];
		for (var i = 0; i < this.alllistprofiles.length; i++)		
		{
			var profileinfo = this.alllistprofiles[ i ];
			var exist=false;
			for (var j=0;j< custompageinfo.listprofiles.length;j++)
			{
				if (custompageinfo.listprofiles[ j ].name == profileinfo.name)
					exist=true;
			}
			
			if (! exist)
				listprofiletoadd.push( profileinfo );
		}
		return listprofiletoadd;
	}
	 
	
	/** add the custom page in a profile
	 * 
	 */
	this.currentpageinfo=null;
	this.addcustompageinprofile = function( custompageinfo ) {
		var self=this;
		custompageinfo.statusinfo="Add in progress";		
		this.currentpageinfo = custompageinfo;
		
		this.statusfoodtruck = "Add in profile "+custompageinfo.installid+" in progress";
		var param = { "appsname":custompageinfo.appsname,
				"appsid": custompageinfo.appsid,
				"displayname" : custompageinfo.displayname,
				"profileid":custompageinfo.addinprofileid,
				"status": custompageinfo.status}
		var json = encodeURI(angular.toJson(param, true));
		$http.get( '?page=custompage_foodtruck&action=addcustompageinprofile&json='+json)
				.then( function ( jsonResult ) {
					// the custom page upgrated is in the list, first position
					
					custompageinfo.statusinfo       = jsonResult.data.statusinfo ;
					custompageinfo.listprofiles     = jsonResult.data.list[ 0 ].listprofiles;
					self.custompage.listevents 		= jsonResult.data.listevents;
					self.custompage.status			= "";
					
				},
				function(jsonResult) {
					alert("downloadcustompage: Can't connect the server ("+jsonResult.status+")");
					self.statusresource				= "Can't connect the server ("+jsonResult.status+")";
					custompageinfo.status			= custompageinfo.oldstatus;
					});

	}

	/**
	 * remove from the profile
	 */ 
 	this.custompageoutofprofile = function( custompageinfo, profileinfo )
	{
		var self=this;
		custompageinfo.statusinfo="Remove in progress";
		
		this.statusfoodtruck = "Remove from profile "+custompageinfo.installid+" in progress";
		var param = { "appsname":custompageinfo.appsname,
				"appsid": custompageinfo.appsid,
				"profileid":profileinfo.id,
				"status": custompageinfo.status}
		var json = encodeURI(angular.toJson(param, true));
			
		$http.get( '?page=custompage_foodtruck&action=removecustompagefromprofile&json='+json )
				.then( function ( jsonResult ) {
					custompageinfo.statusinfo	= jsonResult.data.statusinfo;
					
					custompageinfo.listprofiles 		= jsonResult.data.list[ 0 ].listprofiles;
					
					alert("statusinfo="+angular.json(custompageinfo.statusinfo, true) )
					self.custompage.listevents 		= jsonResult.data.listevents;
					self.custompage.status			= "";
				
				},
				function( jsonResult) {
					alert("addcustompageinprofile: Can't connect the server ("+jsonResult.status+")");
					self.statusresource="Can't connect the server ("+jsonResult.status+")";
				});

	}
	// --------------------------------------------------------------------------
	//
	//  Custom widget
	//
	// --------------------------------------------------------------------------
	// demo
	
	// --------------------------------------------------------------------------
	//
	//  properties
	//
	// --------------------------------------------------------------------------

	this.loadParameters = function() 
	{
		console.log("Load Parameters");
		var self = this;
		self.saveinprogress=true;
		$http.get( '?page=custompage_foodtruck&action=loadparameters' )
		.then( function ( jsonResult ) {
				console.log("loadparameters",jsonResult.data);
				self.saveinprogress=false;
				// $.extend( self.param, jsonResult.data); 
				// angular.copy(jsonResult.data.param, self.param); 
				self.param=jsonResult.data.param;
				if (self.param.github.defaultLogin)
				{
					self.param.github.gitlogin='';
					self.param.github.gitpassword='';
				}
				self.listevents= jsonResult.data.listevents;
				// now, we can reload the artefact
				self.reloadartefacts( true );
			},
		function(jsonResult ) {
			self.saveinprogress=false;

			// alert("loadparameters Error : "+ angular.toJson( jsonResult.data ) );
			this.calculateartefacts( true );
			}
		);
		
	};


	this.saveParameters = function () 
	{
		var self = this;
		self.saveinprogress=true;
		
		var json = encodeURI(angular.toJson(self.param, false));
		console.log("Save Parameters :"+json);
		if (this.param.github.defaultLogin)
		{
			this.param.github.gitlogin='';
			this.param.github.gitpassword='';
		}
		
		$http.get( '?page=custompage_foodtruck&action=saveparameters&json='+json )
		.then( function ( jsonResult ) {	
				self.listevents= jsonResult.data.listevents;
				self.saveinprogress=false;
		},
		function(jsonResult ) {
			alert("Error when save parameters ("+jsonResult.status+")");
			self.saveinprogress=false;
		})	
	}
	// --------------------------------------------------------------------------
	//
	//  Initialisation
	//
	// --------------------------------------------------------------------------
	
	// during the loadParameters, the listCustomPage is started
	this.loadParameters();
	
});



})();